# ECS-163

The y axis displays player A, the one that the action is performed with or on.
The x axis displays times (server times) based on minutes.
Each circle's center is placed at where the player B (one player right now) starts each action
and the radius is set to the duration.
Selection of each bubble highlights and resizes for ease of visualizing, with a tooltip that shows 
who the action is performed on and for how long.